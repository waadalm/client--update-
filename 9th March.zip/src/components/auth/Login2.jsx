import React from "react";

const Login2 = () => {
  return <div>Login2</div>;
};

export default Login2;
