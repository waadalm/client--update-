import React, { Component } from "react";

export default class Footer extends Component {
  render() {
    return (
      <>
        <h1>&cpy;www.eibfs.com {new Date().getFullYear()}</h1>
      </>
    );
  }
}
